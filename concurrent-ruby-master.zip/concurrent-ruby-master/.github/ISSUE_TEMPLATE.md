<!-- Thank you for submitting an issue! -->



<!-- Please fill following if applicable, delete otherwise: -->
******
-   Operating system: linux / mac / win
-   `concurrent-ruby` version: x.y.z
-   `concurrent-ruby-ext` installed: yes / no
-   `concurrent-ruby-edge` used: yes / no
