module Concurrent
  describe LazyRegister do

    pending

  end
end
