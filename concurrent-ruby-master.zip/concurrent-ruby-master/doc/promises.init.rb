require 'concurrent-edge'

def do_stuff
  :stuff
end
