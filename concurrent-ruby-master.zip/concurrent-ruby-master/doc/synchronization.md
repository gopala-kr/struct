# Synchronization

[This document](https://docs.google.com/document/d/1pVzU8w_QF44YzUCCab990Q_WZOdhpKolCIHaiXG-sPw/edit?usp=sharing) 
is moved to Google documents. It will be moved here once final and stabilized.

