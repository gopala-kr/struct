# How to run a benchmark

These benchmarks are using bench9000 gem, see its [readme](https://github.com/jruby/bench9000).
To run the `futures-rubyconf2015` benchmark collection use:

    bundle exec bench9000 report future rubies+truffle --data data.txt --config futures-rubyconf2015
    

    
