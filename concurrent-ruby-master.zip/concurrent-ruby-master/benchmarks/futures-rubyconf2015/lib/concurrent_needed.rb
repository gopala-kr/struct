concurrent_ruby_load_path = File.expand_path(File.join(File.dirname(__FILE__), '../../../lib'))
$LOAD_PATH << concurrent_ruby_load_path unless $LOAD_PATH.include? concurrent_ruby_load_path
