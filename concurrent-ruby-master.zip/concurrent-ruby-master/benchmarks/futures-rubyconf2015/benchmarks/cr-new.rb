require 'cr_future'
FutureImplementation = CRFuture
require 'bench_new'
