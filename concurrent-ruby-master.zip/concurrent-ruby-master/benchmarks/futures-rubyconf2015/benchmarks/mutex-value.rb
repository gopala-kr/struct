require 'mutex_future'
FutureImplementation = MutexFuture
require 'bench_value'
