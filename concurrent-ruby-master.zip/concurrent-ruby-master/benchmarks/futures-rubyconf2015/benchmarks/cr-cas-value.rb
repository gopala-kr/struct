require 'cr_cas_future'
FutureImplementation = CRCasFuture
require 'bench_value'
