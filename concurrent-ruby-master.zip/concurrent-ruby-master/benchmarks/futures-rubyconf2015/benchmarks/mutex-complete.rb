require 'mutex_future'
FutureImplementation = MutexFuture
require 'bench_complete'
