require 'mutex_future'
FutureImplementation = MutexFuture
require 'bench_new'
