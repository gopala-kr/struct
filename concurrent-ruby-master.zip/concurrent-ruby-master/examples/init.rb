require 'concurrent-edge'

def do_stuff
  :stuff
end

Concurrent.use_simple_logger Logger::DEBUG
